﻿namespace Mine_Finder {
    partial class frmMineSweeper {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.btnLoadFromFile = new System.Windows.Forms.Button();
            this.btnFillBoardRandomly = new System.Windows.Forms.Button();
            this.btn_0_0 = new System.Windows.Forms.Button();
            this.btn_0_1 = new System.Windows.Forms.Button();
            this.btn_0_2 = new System.Windows.Forms.Button();
            this.btn_0_3 = new System.Windows.Forms.Button();
            this.btn_0_4 = new System.Windows.Forms.Button();
            this.btn_0_5 = new System.Windows.Forms.Button();
            this.btn_0_6 = new System.Windows.Forms.Button();
            this.btn_0_7 = new System.Windows.Forms.Button();
            this.btn_0_8 = new System.Windows.Forms.Button();
            this.btn_1_0 = new System.Windows.Forms.Button();
            this.btn_1_1 = new System.Windows.Forms.Button();
            this.btn_1_2 = new System.Windows.Forms.Button();
            this.btn_1_3 = new System.Windows.Forms.Button();
            this.btn_1_4 = new System.Windows.Forms.Button();
            this.btn_1_5 = new System.Windows.Forms.Button();
            this.btn_1_6 = new System.Windows.Forms.Button();
            this.btn_1_7 = new System.Windows.Forms.Button();
            this.btn_1_8 = new System.Windows.Forms.Button();
            this.btn_2_0 = new System.Windows.Forms.Button();
            this.btn_2_1 = new System.Windows.Forms.Button();
            this.btn_2_2 = new System.Windows.Forms.Button();
            this.btn_2_3 = new System.Windows.Forms.Button();
            this.btn_2_4 = new System.Windows.Forms.Button();
            this.btn_2_5 = new System.Windows.Forms.Button();
            this.btn_2_6 = new System.Windows.Forms.Button();
            this.btn_2_7 = new System.Windows.Forms.Button();
            this.btn_2_8 = new System.Windows.Forms.Button();
            this.btn_3_0 = new System.Windows.Forms.Button();
            this.btn_3_1 = new System.Windows.Forms.Button();
            this.btn_3_2 = new System.Windows.Forms.Button();
            this.btn_3_3 = new System.Windows.Forms.Button();
            this.btn_3_4 = new System.Windows.Forms.Button();
            this.btn_3_5 = new System.Windows.Forms.Button();
            this.btn_3_6 = new System.Windows.Forms.Button();
            this.btn_3_7 = new System.Windows.Forms.Button();
            this.btn_3_8 = new System.Windows.Forms.Button();
            this.btn_4_0 = new System.Windows.Forms.Button();
            this.btn_4_1 = new System.Windows.Forms.Button();
            this.btn_4_2 = new System.Windows.Forms.Button();
            this.btn_4_3 = new System.Windows.Forms.Button();
            this.btn_4_4 = new System.Windows.Forms.Button();
            this.btn_4_5 = new System.Windows.Forms.Button();
            this.btn_4_6 = new System.Windows.Forms.Button();
            this.btn_4_7 = new System.Windows.Forms.Button();
            this.btn_4_8 = new System.Windows.Forms.Button();
            this.btn_5_0 = new System.Windows.Forms.Button();
            this.btn_5_1 = new System.Windows.Forms.Button();
            this.btn_5_2 = new System.Windows.Forms.Button();
            this.btn_5_3 = new System.Windows.Forms.Button();
            this.btn_5_4 = new System.Windows.Forms.Button();
            this.btn_5_5 = new System.Windows.Forms.Button();
            this.btn_5_6 = new System.Windows.Forms.Button();
            this.btn_5_7 = new System.Windows.Forms.Button();
            this.btn_5_8 = new System.Windows.Forms.Button();
            this.btn_6_0 = new System.Windows.Forms.Button();
            this.btn_6_1 = new System.Windows.Forms.Button();
            this.btn_6_2 = new System.Windows.Forms.Button();
            this.btn_6_3 = new System.Windows.Forms.Button();
            this.btn_6_4 = new System.Windows.Forms.Button();
            this.btn_6_5 = new System.Windows.Forms.Button();
            this.btn_6_6 = new System.Windows.Forms.Button();
            this.btn_6_7 = new System.Windows.Forms.Button();
            this.btn_6_8 = new System.Windows.Forms.Button();
            this.btn_7_0 = new System.Windows.Forms.Button();
            this.btn_7_1 = new System.Windows.Forms.Button();
            this.btn_7_2 = new System.Windows.Forms.Button();
            this.btn_7_3 = new System.Windows.Forms.Button();
            this.btn_7_4 = new System.Windows.Forms.Button();
            this.btn_7_5 = new System.Windows.Forms.Button();
            this.btn_7_6 = new System.Windows.Forms.Button();
            this.btn_7_7 = new System.Windows.Forms.Button();
            this.btn_7_8 = new System.Windows.Forms.Button();
            this.btn_8_0 = new System.Windows.Forms.Button();
            this.btn_8_1 = new System.Windows.Forms.Button();
            this.btn_8_2 = new System.Windows.Forms.Button();
            this.btn_8_3 = new System.Windows.Forms.Button();
            this.btn_8_4 = new System.Windows.Forms.Button();
            this.btn_8_5 = new System.Windows.Forms.Button();
            this.btn_8_6 = new System.Windows.Forms.Button();
            this.btn_8_7 = new System.Windows.Forms.Button();
            this.btn_8_8 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLoadFromFile
            // 
            this.btnLoadFromFile.Location = new System.Drawing.Point(12, 12);
            this.btnLoadFromFile.Name = "btnLoadFromFile";
            this.btnLoadFromFile.Size = new System.Drawing.Size(202, 38);
            this.btnLoadFromFile.TabIndex = 0;
            this.btnLoadFromFile.Text = "Load from File";
            this.btnLoadFromFile.UseVisualStyleBackColor = true;
            this.btnLoadFromFile.Click += new System.EventHandler(this.btnLoadFromFile_Click);
            // 
            // btnFillBoardRandomly
            // 
            this.btnFillBoardRandomly.Location = new System.Drawing.Point(235, 12);
            this.btnFillBoardRandomly.Name = "btnFillBoardRandomly";
            this.btnFillBoardRandomly.Size = new System.Drawing.Size(221, 38);
            this.btnFillBoardRandomly.TabIndex = 1;
            this.btnFillBoardRandomly.Text = "Fill Board Randomly";
            this.btnFillBoardRandomly.UseVisualStyleBackColor = true;
            this.btnFillBoardRandomly.Click += new System.EventHandler(this.btnFillBoardRandomly_Click);
            // 
            // btn_0_0
            // 
            this.btn_0_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_0.Location = new System.Drawing.Point(12, 56);
            this.btn_0_0.Name = "btn_0_0";
            this.btn_0_0.Size = new System.Drawing.Size(44, 41);
            this.btn_0_0.TabIndex = 2;
            this.btn_0_0.Text = "?";
            this.btn_0_0.UseVisualStyleBackColor = false;
            // 
            // btn_0_1
            // 
            this.btn_0_1.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_1.Location = new System.Drawing.Point(62, 56);
            this.btn_0_1.Name = "btn_0_1";
            this.btn_0_1.Size = new System.Drawing.Size(44, 41);
            this.btn_0_1.TabIndex = 3;
            this.btn_0_1.Text = "?";
            this.btn_0_1.UseVisualStyleBackColor = false;
            // 
            // btn_0_2
            // 
            this.btn_0_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_2.Location = new System.Drawing.Point(112, 56);
            this.btn_0_2.Name = "btn_0_2";
            this.btn_0_2.Size = new System.Drawing.Size(44, 41);
            this.btn_0_2.TabIndex = 4;
            this.btn_0_2.Text = "?";
            this.btn_0_2.UseVisualStyleBackColor = false;
            // 
            // btn_0_3
            // 
            this.btn_0_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_3.Location = new System.Drawing.Point(162, 56);
            this.btn_0_3.Name = "btn_0_3";
            this.btn_0_3.Size = new System.Drawing.Size(44, 41);
            this.btn_0_3.TabIndex = 5;
            this.btn_0_3.Text = "?";
            this.btn_0_3.UseVisualStyleBackColor = false;
            // 
            // btn_0_4
            // 
            this.btn_0_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_4.Location = new System.Drawing.Point(212, 56);
            this.btn_0_4.Name = "btn_0_4";
            this.btn_0_4.Size = new System.Drawing.Size(44, 41);
            this.btn_0_4.TabIndex = 6;
            this.btn_0_4.Text = "?";
            this.btn_0_4.UseVisualStyleBackColor = false;
            // 
            // btn_0_5
            // 
            this.btn_0_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_5.Location = new System.Drawing.Point(262, 56);
            this.btn_0_5.Name = "btn_0_5";
            this.btn_0_5.Size = new System.Drawing.Size(44, 41);
            this.btn_0_5.TabIndex = 7;
            this.btn_0_5.Text = "?";
            this.btn_0_5.UseVisualStyleBackColor = false;
            // 
            // btn_0_6
            // 
            this.btn_0_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_6.Location = new System.Drawing.Point(312, 56);
            this.btn_0_6.Name = "btn_0_6";
            this.btn_0_6.Size = new System.Drawing.Size(44, 41);
            this.btn_0_6.TabIndex = 8;
            this.btn_0_6.Text = "?";
            this.btn_0_6.UseVisualStyleBackColor = false;
            // 
            // btn_0_7
            // 
            this.btn_0_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_7.Location = new System.Drawing.Point(362, 56);
            this.btn_0_7.Name = "btn_0_7";
            this.btn_0_7.Size = new System.Drawing.Size(44, 41);
            this.btn_0_7.TabIndex = 9;
            this.btn_0_7.Text = "?";
            this.btn_0_7.UseVisualStyleBackColor = false;
            // 
            // btn_0_8
            // 
            this.btn_0_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_0_8.Location = new System.Drawing.Point(412, 56);
            this.btn_0_8.Name = "btn_0_8";
            this.btn_0_8.Size = new System.Drawing.Size(44, 41);
            this.btn_0_8.TabIndex = 10;
            this.btn_0_8.Text = "?";
            this.btn_0_8.UseVisualStyleBackColor = false;
            // 
            // btn_1_0
            // 
            this.btn_1_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_0.Location = new System.Drawing.Point(12, 103);
            this.btn_1_0.Name = "btn_1_0";
            this.btn_1_0.Size = new System.Drawing.Size(44, 41);
            this.btn_1_0.TabIndex = 11;
            this.btn_1_0.Text = "?";
            this.btn_1_0.UseVisualStyleBackColor = false;
            // 
            // btn_1_1
            // 
            this.btn_1_1.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_1.Location = new System.Drawing.Point(62, 103);
            this.btn_1_1.Name = "btn_1_1";
            this.btn_1_1.Size = new System.Drawing.Size(44, 41);
            this.btn_1_1.TabIndex = 12;
            this.btn_1_1.Text = "?";
            this.btn_1_1.UseVisualStyleBackColor = false;
            // 
            // btn_1_2
            // 
            this.btn_1_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_2.Location = new System.Drawing.Point(112, 103);
            this.btn_1_2.Name = "btn_1_2";
            this.btn_1_2.Size = new System.Drawing.Size(44, 41);
            this.btn_1_2.TabIndex = 13;
            this.btn_1_2.Text = "?";
            this.btn_1_2.UseVisualStyleBackColor = false;
            // 
            // btn_1_3
            // 
            this.btn_1_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_3.Location = new System.Drawing.Point(162, 103);
            this.btn_1_3.Name = "btn_1_3";
            this.btn_1_3.Size = new System.Drawing.Size(44, 41);
            this.btn_1_3.TabIndex = 14;
            this.btn_1_3.Text = "?";
            this.btn_1_3.UseVisualStyleBackColor = false;
            // 
            // btn_1_4
            // 
            this.btn_1_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_4.Location = new System.Drawing.Point(212, 103);
            this.btn_1_4.Name = "btn_1_4";
            this.btn_1_4.Size = new System.Drawing.Size(44, 41);
            this.btn_1_4.TabIndex = 15;
            this.btn_1_4.Text = "?";
            this.btn_1_4.UseVisualStyleBackColor = false;
            // 
            // btn_1_5
            // 
            this.btn_1_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_5.Location = new System.Drawing.Point(262, 103);
            this.btn_1_5.Name = "btn_1_5";
            this.btn_1_5.Size = new System.Drawing.Size(44, 41);
            this.btn_1_5.TabIndex = 16;
            this.btn_1_5.Text = "?";
            this.btn_1_5.UseVisualStyleBackColor = false;
            // 
            // btn_1_6
            // 
            this.btn_1_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_6.Location = new System.Drawing.Point(312, 103);
            this.btn_1_6.Name = "btn_1_6";
            this.btn_1_6.Size = new System.Drawing.Size(44, 41);
            this.btn_1_6.TabIndex = 17;
            this.btn_1_6.Text = "?";
            this.btn_1_6.UseVisualStyleBackColor = false;
            // 
            // btn_1_7
            // 
            this.btn_1_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_7.Location = new System.Drawing.Point(362, 103);
            this.btn_1_7.Name = "btn_1_7";
            this.btn_1_7.Size = new System.Drawing.Size(44, 41);
            this.btn_1_7.TabIndex = 18;
            this.btn_1_7.Text = "?";
            this.btn_1_7.UseVisualStyleBackColor = false;
            // 
            // btn_1_8
            // 
            this.btn_1_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_1_8.Location = new System.Drawing.Point(412, 103);
            this.btn_1_8.Name = "btn_1_8";
            this.btn_1_8.Size = new System.Drawing.Size(44, 41);
            this.btn_1_8.TabIndex = 19;
            this.btn_1_8.Text = "?";
            this.btn_1_8.UseVisualStyleBackColor = false;
            // 
            // btn_2_0
            // 
            this.btn_2_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_0.Location = new System.Drawing.Point(12, 150);
            this.btn_2_0.Name = "btn_2_0";
            this.btn_2_0.Size = new System.Drawing.Size(44, 41);
            this.btn_2_0.TabIndex = 20;
            this.btn_2_0.Text = "?";
            this.btn_2_0.UseVisualStyleBackColor = false;
            // 
            // btn_2_1
            // 
            this.btn_2_1.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_1.Location = new System.Drawing.Point(62, 150);
            this.btn_2_1.Name = "btn_2_1";
            this.btn_2_1.Size = new System.Drawing.Size(44, 41);
            this.btn_2_1.TabIndex = 21;
            this.btn_2_1.Text = "?";
            this.btn_2_1.UseVisualStyleBackColor = false;
            // 
            // btn_2_2
            // 
            this.btn_2_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_2.Location = new System.Drawing.Point(112, 150);
            this.btn_2_2.Name = "btn_2_2";
            this.btn_2_2.Size = new System.Drawing.Size(44, 41);
            this.btn_2_2.TabIndex = 22;
            this.btn_2_2.Text = "?";
            this.btn_2_2.UseVisualStyleBackColor = false;
            // 
            // btn_2_3
            // 
            this.btn_2_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_3.Location = new System.Drawing.Point(162, 150);
            this.btn_2_3.Name = "btn_2_3";
            this.btn_2_3.Size = new System.Drawing.Size(44, 41);
            this.btn_2_3.TabIndex = 23;
            this.btn_2_3.Text = "?";
            this.btn_2_3.UseVisualStyleBackColor = false;
            // 
            // btn_2_4
            // 
            this.btn_2_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_4.Location = new System.Drawing.Point(212, 150);
            this.btn_2_4.Name = "btn_2_4";
            this.btn_2_4.Size = new System.Drawing.Size(44, 41);
            this.btn_2_4.TabIndex = 24;
            this.btn_2_4.Text = "?";
            this.btn_2_4.UseVisualStyleBackColor = false;
            // 
            // btn_2_5
            // 
            this.btn_2_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_5.Location = new System.Drawing.Point(262, 150);
            this.btn_2_5.Name = "btn_2_5";
            this.btn_2_5.Size = new System.Drawing.Size(44, 41);
            this.btn_2_5.TabIndex = 25;
            this.btn_2_5.Text = "?";
            this.btn_2_5.UseVisualStyleBackColor = false;
            // 
            // btn_2_6
            // 
            this.btn_2_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_6.Location = new System.Drawing.Point(312, 150);
            this.btn_2_6.Name = "btn_2_6";
            this.btn_2_6.Size = new System.Drawing.Size(44, 41);
            this.btn_2_6.TabIndex = 26;
            this.btn_2_6.Text = "?";
            this.btn_2_6.UseVisualStyleBackColor = false;
            // 
            // btn_2_7
            // 
            this.btn_2_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_7.Location = new System.Drawing.Point(362, 150);
            this.btn_2_7.Name = "btn_2_7";
            this.btn_2_7.Size = new System.Drawing.Size(44, 41);
            this.btn_2_7.TabIndex = 27;
            this.btn_2_7.Text = "?";
            this.btn_2_7.UseVisualStyleBackColor = false;
            // 
            // btn_2_8
            // 
            this.btn_2_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_2_8.Location = new System.Drawing.Point(412, 150);
            this.btn_2_8.Name = "btn_2_8";
            this.btn_2_8.Size = new System.Drawing.Size(44, 41);
            this.btn_2_8.TabIndex = 28;
            this.btn_2_8.Text = "?";
            this.btn_2_8.UseVisualStyleBackColor = false;
            // 
            // btn_3_0
            // 
            this.btn_3_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_0.Location = new System.Drawing.Point(12, 197);
            this.btn_3_0.Name = "btn_3_0";
            this.btn_3_0.Size = new System.Drawing.Size(44, 41);
            this.btn_3_0.TabIndex = 29;
            this.btn_3_0.Text = "?";
            this.btn_3_0.UseVisualStyleBackColor = false;
            // 
            // btn_3_1
            // 
            this.btn_3_1.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_1.Location = new System.Drawing.Point(62, 197);
            this.btn_3_1.Name = "btn_3_1";
            this.btn_3_1.Size = new System.Drawing.Size(44, 41);
            this.btn_3_1.TabIndex = 30;
            this.btn_3_1.Text = "?";
            this.btn_3_1.UseVisualStyleBackColor = false;
            // 
            // btn_3_2
            // 
            this.btn_3_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_2.Location = new System.Drawing.Point(112, 197);
            this.btn_3_2.Name = "btn_3_2";
            this.btn_3_2.Size = new System.Drawing.Size(44, 41);
            this.btn_3_2.TabIndex = 31;
            this.btn_3_2.Text = "?";
            this.btn_3_2.UseVisualStyleBackColor = false;
            // 
            // btn_3_3
            // 
            this.btn_3_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_3.Location = new System.Drawing.Point(162, 197);
            this.btn_3_3.Name = "btn_3_3";
            this.btn_3_3.Size = new System.Drawing.Size(44, 41);
            this.btn_3_3.TabIndex = 32;
            this.btn_3_3.Text = "?";
            this.btn_3_3.UseVisualStyleBackColor = false;
            // 
            // btn_3_4
            // 
            this.btn_3_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_4.Location = new System.Drawing.Point(212, 197);
            this.btn_3_4.Name = "btn_3_4";
            this.btn_3_4.Size = new System.Drawing.Size(44, 41);
            this.btn_3_4.TabIndex = 33;
            this.btn_3_4.Text = "?";
            this.btn_3_4.UseVisualStyleBackColor = false;
            // 
            // btn_3_5
            // 
            this.btn_3_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_5.Location = new System.Drawing.Point(262, 197);
            this.btn_3_5.Name = "btn_3_5";
            this.btn_3_5.Size = new System.Drawing.Size(44, 41);
            this.btn_3_5.TabIndex = 34;
            this.btn_3_5.Text = "?";
            this.btn_3_5.UseVisualStyleBackColor = false;
            // 
            // btn_3_6
            // 
            this.btn_3_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_6.Location = new System.Drawing.Point(312, 197);
            this.btn_3_6.Name = "btn_3_6";
            this.btn_3_6.Size = new System.Drawing.Size(44, 41);
            this.btn_3_6.TabIndex = 35;
            this.btn_3_6.Text = "?";
            this.btn_3_6.UseVisualStyleBackColor = false;
            // 
            // btn_3_7
            // 
            this.btn_3_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_7.Location = new System.Drawing.Point(362, 197);
            this.btn_3_7.Name = "btn_3_7";
            this.btn_3_7.Size = new System.Drawing.Size(44, 41);
            this.btn_3_7.TabIndex = 36;
            this.btn_3_7.Text = "?";
            this.btn_3_7.UseVisualStyleBackColor = false;
            // 
            // btn_3_8
            // 
            this.btn_3_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_3_8.Location = new System.Drawing.Point(412, 197);
            this.btn_3_8.Name = "btn_3_8";
            this.btn_3_8.Size = new System.Drawing.Size(44, 41);
            this.btn_3_8.TabIndex = 37;
            this.btn_3_8.Text = "?";
            this.btn_3_8.UseVisualStyleBackColor = false;
            // 
            // btn_4_0
            // 
            this.btn_4_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_0.Location = new System.Drawing.Point(12, 244);
            this.btn_4_0.Name = "btn_4_0";
            this.btn_4_0.Size = new System.Drawing.Size(44, 41);
            this.btn_4_0.TabIndex = 38;
            this.btn_4_0.Text = "?";
            this.btn_4_0.UseVisualStyleBackColor = false;
            // 
            // btn_4_1
            // 
            this.btn_4_1.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_1.Location = new System.Drawing.Point(62, 244);
            this.btn_4_1.Name = "btn_4_1";
            this.btn_4_1.Size = new System.Drawing.Size(44, 41);
            this.btn_4_1.TabIndex = 39;
            this.btn_4_1.Text = "?";
            this.btn_4_1.UseVisualStyleBackColor = false;
            // 
            // btn_4_2
            // 
            this.btn_4_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_2.Location = new System.Drawing.Point(112, 244);
            this.btn_4_2.Name = "btn_4_2";
            this.btn_4_2.Size = new System.Drawing.Size(44, 41);
            this.btn_4_2.TabIndex = 40;
            this.btn_4_2.Text = "?";
            this.btn_4_2.UseVisualStyleBackColor = false;
            // 
            // btn_4_3
            // 
            this.btn_4_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_3.Location = new System.Drawing.Point(162, 244);
            this.btn_4_3.Name = "btn_4_3";
            this.btn_4_3.Size = new System.Drawing.Size(44, 41);
            this.btn_4_3.TabIndex = 41;
            this.btn_4_3.Text = "?";
            this.btn_4_3.UseVisualStyleBackColor = false;
            // 
            // btn_4_4
            // 
            this.btn_4_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_4.Location = new System.Drawing.Point(212, 244);
            this.btn_4_4.Name = "btn_4_4";
            this.btn_4_4.Size = new System.Drawing.Size(44, 41);
            this.btn_4_4.TabIndex = 42;
            this.btn_4_4.Text = "?";
            this.btn_4_4.UseVisualStyleBackColor = false;
            // 
            // btn_4_5
            // 
            this.btn_4_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_5.Location = new System.Drawing.Point(262, 244);
            this.btn_4_5.Name = "btn_4_5";
            this.btn_4_5.Size = new System.Drawing.Size(44, 41);
            this.btn_4_5.TabIndex = 43;
            this.btn_4_5.Text = "?";
            this.btn_4_5.UseVisualStyleBackColor = false;
            // 
            // btn_4_6
            // 
            this.btn_4_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_6.Location = new System.Drawing.Point(312, 244);
            this.btn_4_6.Name = "btn_4_6";
            this.btn_4_6.Size = new System.Drawing.Size(44, 41);
            this.btn_4_6.TabIndex = 44;
            this.btn_4_6.Text = "?";
            this.btn_4_6.UseVisualStyleBackColor = false;
            // 
            // btn_4_7
            // 
            this.btn_4_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_7.Location = new System.Drawing.Point(362, 244);
            this.btn_4_7.Name = "btn_4_7";
            this.btn_4_7.Size = new System.Drawing.Size(44, 41);
            this.btn_4_7.TabIndex = 45;
            this.btn_4_7.Text = "?";
            this.btn_4_7.UseVisualStyleBackColor = false;
            // 
            // btn_4_8
            // 
            this.btn_4_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_4_8.Location = new System.Drawing.Point(412, 244);
            this.btn_4_8.Name = "btn_4_8";
            this.btn_4_8.Size = new System.Drawing.Size(44, 41);
            this.btn_4_8.TabIndex = 46;
            this.btn_4_8.Text = "?";
            this.btn_4_8.UseVisualStyleBackColor = false;
            // 
            // btn_5_0
            // 
            this.btn_5_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_5_0.Location = new System.Drawing.Point(12, 291);
            this.btn_5_0.Name = "btn_5_0";
            this.btn_5_0.Size = new System.Drawing.Size(44, 41);
            this.btn_5_0.TabIndex = 47;
            this.btn_5_0.Text = "?";
            this.btn_5_0.UseVisualStyleBackColor = false;
            // 
            // btn_5_1
            // 
            this.btn_5_1.Location = new System.Drawing.Point(62, 291);
            this.btn_5_1.Name = "btn_5_1";
            this.btn_5_1.Size = new System.Drawing.Size(44, 41);
            this.btn_5_1.TabIndex = 48;
            this.btn_5_1.Text = "?";
            this.btn_5_1.UseVisualStyleBackColor = true;
            // 
            // btn_5_2
            // 
            this.btn_5_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_5_2.Location = new System.Drawing.Point(112, 291);
            this.btn_5_2.Name = "btn_5_2";
            this.btn_5_2.Size = new System.Drawing.Size(44, 41);
            this.btn_5_2.TabIndex = 49;
            this.btn_5_2.Text = "?";
            this.btn_5_2.UseVisualStyleBackColor = false;
            // 
            // btn_5_3
            // 
            this.btn_5_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_5_3.Location = new System.Drawing.Point(162, 291);
            this.btn_5_3.Name = "btn_5_3";
            this.btn_5_3.Size = new System.Drawing.Size(44, 41);
            this.btn_5_3.TabIndex = 50;
            this.btn_5_3.Text = "?";
            this.btn_5_3.UseVisualStyleBackColor = false;
            // 
            // btn_5_4
            // 
            this.btn_5_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_5_4.Location = new System.Drawing.Point(212, 291);
            this.btn_5_4.Name = "btn_5_4";
            this.btn_5_4.Size = new System.Drawing.Size(44, 41);
            this.btn_5_4.TabIndex = 51;
            this.btn_5_4.Text = "?";
            this.btn_5_4.UseVisualStyleBackColor = false;
            // 
            // btn_5_5
            // 
            this.btn_5_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_5_5.Location = new System.Drawing.Point(262, 291);
            this.btn_5_5.Name = "btn_5_5";
            this.btn_5_5.Size = new System.Drawing.Size(44, 41);
            this.btn_5_5.TabIndex = 52;
            this.btn_5_5.Text = "?";
            this.btn_5_5.UseVisualStyleBackColor = false;
            // 
            // btn_5_6
            // 
            this.btn_5_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_5_6.Location = new System.Drawing.Point(312, 291);
            this.btn_5_6.Name = "btn_5_6";
            this.btn_5_6.Size = new System.Drawing.Size(44, 41);
            this.btn_5_6.TabIndex = 53;
            this.btn_5_6.Text = "?";
            this.btn_5_6.UseVisualStyleBackColor = false;
            // 
            // btn_5_7
            // 
            this.btn_5_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_5_7.Location = new System.Drawing.Point(362, 291);
            this.btn_5_7.Name = "btn_5_7";
            this.btn_5_7.Size = new System.Drawing.Size(44, 41);
            this.btn_5_7.TabIndex = 54;
            this.btn_5_7.Text = "?";
            this.btn_5_7.UseVisualStyleBackColor = false;
            // 
            // btn_5_8
            // 
            this.btn_5_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_5_8.Location = new System.Drawing.Point(412, 291);
            this.btn_5_8.Name = "btn_5_8";
            this.btn_5_8.Size = new System.Drawing.Size(44, 41);
            this.btn_5_8.TabIndex = 55;
            this.btn_5_8.Text = "?";
            this.btn_5_8.UseVisualStyleBackColor = false;
            // 
            // btn_6_0
            // 
            this.btn_6_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_0.Location = new System.Drawing.Point(12, 338);
            this.btn_6_0.Name = "btn_6_0";
            this.btn_6_0.Size = new System.Drawing.Size(44, 41);
            this.btn_6_0.TabIndex = 56;
            this.btn_6_0.Text = "?";
            this.btn_6_0.UseVisualStyleBackColor = false;
            // 
            // btn_6_1
            // 
            this.btn_6_1.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_1.Location = new System.Drawing.Point(62, 338);
            this.btn_6_1.Name = "btn_6_1";
            this.btn_6_1.Size = new System.Drawing.Size(44, 41);
            this.btn_6_1.TabIndex = 57;
            this.btn_6_1.Text = "?";
            this.btn_6_1.UseVisualStyleBackColor = false;
            // 
            // btn_6_2
            // 
            this.btn_6_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_2.Location = new System.Drawing.Point(112, 338);
            this.btn_6_2.Name = "btn_6_2";
            this.btn_6_2.Size = new System.Drawing.Size(44, 41);
            this.btn_6_2.TabIndex = 58;
            this.btn_6_2.Text = "?";
            this.btn_6_2.UseVisualStyleBackColor = false;
            // 
            // btn_6_3
            // 
            this.btn_6_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_3.Location = new System.Drawing.Point(162, 338);
            this.btn_6_3.Name = "btn_6_3";
            this.btn_6_3.Size = new System.Drawing.Size(44, 41);
            this.btn_6_3.TabIndex = 59;
            this.btn_6_3.Text = "?";
            this.btn_6_3.UseVisualStyleBackColor = false;
            // 
            // btn_6_4
            // 
            this.btn_6_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_4.Location = new System.Drawing.Point(212, 338);
            this.btn_6_4.Name = "btn_6_4";
            this.btn_6_4.Size = new System.Drawing.Size(44, 41);
            this.btn_6_4.TabIndex = 60;
            this.btn_6_4.Text = "?";
            this.btn_6_4.UseVisualStyleBackColor = false;
            // 
            // btn_6_5
            // 
            this.btn_6_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_5.Location = new System.Drawing.Point(262, 338);
            this.btn_6_5.Name = "btn_6_5";
            this.btn_6_5.Size = new System.Drawing.Size(44, 41);
            this.btn_6_5.TabIndex = 61;
            this.btn_6_5.Text = "?";
            this.btn_6_5.UseVisualStyleBackColor = false;
            // 
            // btn_6_6
            // 
            this.btn_6_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_6.Location = new System.Drawing.Point(312, 338);
            this.btn_6_6.Name = "btn_6_6";
            this.btn_6_6.Size = new System.Drawing.Size(44, 41);
            this.btn_6_6.TabIndex = 62;
            this.btn_6_6.Text = "?";
            this.btn_6_6.UseVisualStyleBackColor = false;
            // 
            // btn_6_7
            // 
            this.btn_6_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_7.Location = new System.Drawing.Point(362, 338);
            this.btn_6_7.Name = "btn_6_7";
            this.btn_6_7.Size = new System.Drawing.Size(44, 41);
            this.btn_6_7.TabIndex = 63;
            this.btn_6_7.Text = "?";
            this.btn_6_7.UseVisualStyleBackColor = false;
            // 
            // btn_6_8
            // 
            this.btn_6_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_6_8.Location = new System.Drawing.Point(412, 338);
            this.btn_6_8.Name = "btn_6_8";
            this.btn_6_8.Size = new System.Drawing.Size(44, 41);
            this.btn_6_8.TabIndex = 64;
            this.btn_6_8.Text = "?";
            this.btn_6_8.UseVisualStyleBackColor = false;
            // 
            // btn_7_0
            // 
            this.btn_7_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_0.Location = new System.Drawing.Point(12, 385);
            this.btn_7_0.Name = "btn_7_0";
            this.btn_7_0.Size = new System.Drawing.Size(44, 41);
            this.btn_7_0.TabIndex = 65;
            this.btn_7_0.Text = "?";
            this.btn_7_0.UseVisualStyleBackColor = false;
            // 
            // btn_7_1
            // 
            this.btn_7_1.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_1.Location = new System.Drawing.Point(62, 385);
            this.btn_7_1.Name = "btn_7_1";
            this.btn_7_1.Size = new System.Drawing.Size(44, 41);
            this.btn_7_1.TabIndex = 66;
            this.btn_7_1.Text = "?";
            this.btn_7_1.UseVisualStyleBackColor = false;
            // 
            // btn_7_2
            // 
            this.btn_7_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_2.Location = new System.Drawing.Point(112, 385);
            this.btn_7_2.Name = "btn_7_2";
            this.btn_7_2.Size = new System.Drawing.Size(44, 41);
            this.btn_7_2.TabIndex = 67;
            this.btn_7_2.Text = "?";
            this.btn_7_2.UseVisualStyleBackColor = false;
            // 
            // btn_7_3
            // 
            this.btn_7_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_3.Location = new System.Drawing.Point(162, 385);
            this.btn_7_3.Name = "btn_7_3";
            this.btn_7_3.Size = new System.Drawing.Size(44, 41);
            this.btn_7_3.TabIndex = 68;
            this.btn_7_3.Text = "?";
            this.btn_7_3.UseVisualStyleBackColor = false;
            // 
            // btn_7_4
            // 
            this.btn_7_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_4.Location = new System.Drawing.Point(212, 385);
            this.btn_7_4.Name = "btn_7_4";
            this.btn_7_4.Size = new System.Drawing.Size(44, 41);
            this.btn_7_4.TabIndex = 69;
            this.btn_7_4.Text = "?";
            this.btn_7_4.UseVisualStyleBackColor = false;
            // 
            // btn_7_5
            // 
            this.btn_7_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_5.Location = new System.Drawing.Point(262, 385);
            this.btn_7_5.Name = "btn_7_5";
            this.btn_7_5.Size = new System.Drawing.Size(44, 41);
            this.btn_7_5.TabIndex = 70;
            this.btn_7_5.Text = "?";
            this.btn_7_5.UseVisualStyleBackColor = false;
            // 
            // btn_7_6
            // 
            this.btn_7_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_6.Location = new System.Drawing.Point(312, 385);
            this.btn_7_6.Name = "btn_7_6";
            this.btn_7_6.Size = new System.Drawing.Size(44, 41);
            this.btn_7_6.TabIndex = 71;
            this.btn_7_6.Text = "?";
            this.btn_7_6.UseVisualStyleBackColor = false;
            // 
            // btn_7_7
            // 
            this.btn_7_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_7.Location = new System.Drawing.Point(362, 385);
            this.btn_7_7.Name = "btn_7_7";
            this.btn_7_7.Size = new System.Drawing.Size(44, 41);
            this.btn_7_7.TabIndex = 72;
            this.btn_7_7.Text = "?";
            this.btn_7_7.UseVisualStyleBackColor = false;
            // 
            // btn_7_8
            // 
            this.btn_7_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_7_8.Location = new System.Drawing.Point(412, 385);
            this.btn_7_8.Name = "btn_7_8";
            this.btn_7_8.Size = new System.Drawing.Size(44, 41);
            this.btn_7_8.TabIndex = 73;
            this.btn_7_8.Text = "?";
            this.btn_7_8.UseVisualStyleBackColor = false;
            // 
            // btn_8_0
            // 
            this.btn_8_0.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_0.Location = new System.Drawing.Point(12, 432);
            this.btn_8_0.Name = "btn_8_0";
            this.btn_8_0.Size = new System.Drawing.Size(44, 41);
            this.btn_8_0.TabIndex = 74;
            this.btn_8_0.Text = "?";
            this.btn_8_0.UseVisualStyleBackColor = false;
            // 
            // btn_8_1
            // 
            this.btn_8_1.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_1.Location = new System.Drawing.Point(62, 432);
            this.btn_8_1.Name = "btn_8_1";
            this.btn_8_1.Size = new System.Drawing.Size(44, 41);
            this.btn_8_1.TabIndex = 75;
            this.btn_8_1.Text = "?";
            this.btn_8_1.UseVisualStyleBackColor = false;
            // 
            // btn_8_2
            // 
            this.btn_8_2.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_2.Location = new System.Drawing.Point(112, 432);
            this.btn_8_2.Name = "btn_8_2";
            this.btn_8_2.Size = new System.Drawing.Size(44, 41);
            this.btn_8_2.TabIndex = 76;
            this.btn_8_2.Text = "?";
            this.btn_8_2.UseVisualStyleBackColor = false;
            // 
            // btn_8_3
            // 
            this.btn_8_3.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_3.Location = new System.Drawing.Point(162, 432);
            this.btn_8_3.Name = "btn_8_3";
            this.btn_8_3.Size = new System.Drawing.Size(44, 41);
            this.btn_8_3.TabIndex = 77;
            this.btn_8_3.Text = "?";
            this.btn_8_3.UseVisualStyleBackColor = false;
            // 
            // btn_8_4
            // 
            this.btn_8_4.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_4.Location = new System.Drawing.Point(212, 432);
            this.btn_8_4.Name = "btn_8_4";
            this.btn_8_4.Size = new System.Drawing.Size(44, 41);
            this.btn_8_4.TabIndex = 78;
            this.btn_8_4.Text = "?";
            this.btn_8_4.UseVisualStyleBackColor = false;
            // 
            // btn_8_5
            // 
            this.btn_8_5.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_5.Location = new System.Drawing.Point(262, 432);
            this.btn_8_5.Name = "btn_8_5";
            this.btn_8_5.Size = new System.Drawing.Size(44, 41);
            this.btn_8_5.TabIndex = 79;
            this.btn_8_5.Text = "?";
            this.btn_8_5.UseVisualStyleBackColor = false;
            // 
            // btn_8_6
            // 
            this.btn_8_6.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_6.Location = new System.Drawing.Point(312, 432);
            this.btn_8_6.Name = "btn_8_6";
            this.btn_8_6.Size = new System.Drawing.Size(44, 41);
            this.btn_8_6.TabIndex = 80;
            this.btn_8_6.Text = "?";
            this.btn_8_6.UseVisualStyleBackColor = false;
            // 
            // btn_8_7
            // 
            this.btn_8_7.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_7.Location = new System.Drawing.Point(362, 432);
            this.btn_8_7.Name = "btn_8_7";
            this.btn_8_7.Size = new System.Drawing.Size(44, 41);
            this.btn_8_7.TabIndex = 81;
            this.btn_8_7.Text = "?";
            this.btn_8_7.UseVisualStyleBackColor = false;
            // 
            // btn_8_8
            // 
            this.btn_8_8.BackColor = System.Drawing.Color.Transparent;
            this.btn_8_8.Location = new System.Drawing.Point(412, 432);
            this.btn_8_8.Name = "btn_8_8";
            this.btn_8_8.Size = new System.Drawing.Size(44, 41);
            this.btn_8_8.TabIndex = 82;
            this.btn_8_8.Text = "?";
            this.btn_8_8.UseVisualStyleBackColor = false;
            // 
            // frmMineSweeper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 484);
            this.Controls.Add(this.btn_8_8);
            this.Controls.Add(this.btn_8_7);
            this.Controls.Add(this.btn_8_6);
            this.Controls.Add(this.btn_8_5);
            this.Controls.Add(this.btn_8_4);
            this.Controls.Add(this.btn_8_3);
            this.Controls.Add(this.btn_8_2);
            this.Controls.Add(this.btn_8_1);
            this.Controls.Add(this.btn_8_0);
            this.Controls.Add(this.btn_7_8);
            this.Controls.Add(this.btn_7_7);
            this.Controls.Add(this.btn_7_6);
            this.Controls.Add(this.btn_7_5);
            this.Controls.Add(this.btn_7_4);
            this.Controls.Add(this.btn_7_3);
            this.Controls.Add(this.btn_7_2);
            this.Controls.Add(this.btn_7_1);
            this.Controls.Add(this.btn_7_0);
            this.Controls.Add(this.btn_6_8);
            this.Controls.Add(this.btn_6_7);
            this.Controls.Add(this.btn_6_6);
            this.Controls.Add(this.btn_6_5);
            this.Controls.Add(this.btn_6_4);
            this.Controls.Add(this.btn_6_3);
            this.Controls.Add(this.btn_6_2);
            this.Controls.Add(this.btn_6_1);
            this.Controls.Add(this.btn_6_0);
            this.Controls.Add(this.btn_5_8);
            this.Controls.Add(this.btn_5_7);
            this.Controls.Add(this.btn_5_6);
            this.Controls.Add(this.btn_5_5);
            this.Controls.Add(this.btn_5_4);
            this.Controls.Add(this.btn_5_3);
            this.Controls.Add(this.btn_5_2);
            this.Controls.Add(this.btn_5_1);
            this.Controls.Add(this.btn_5_0);
            this.Controls.Add(this.btn_4_8);
            this.Controls.Add(this.btn_4_7);
            this.Controls.Add(this.btn_4_6);
            this.Controls.Add(this.btn_4_5);
            this.Controls.Add(this.btn_4_4);
            this.Controls.Add(this.btn_4_3);
            this.Controls.Add(this.btn_4_2);
            this.Controls.Add(this.btn_4_1);
            this.Controls.Add(this.btn_4_0);
            this.Controls.Add(this.btn_3_8);
            this.Controls.Add(this.btn_3_7);
            this.Controls.Add(this.btn_3_6);
            this.Controls.Add(this.btn_3_5);
            this.Controls.Add(this.btn_3_4);
            this.Controls.Add(this.btn_3_3);
            this.Controls.Add(this.btn_3_2);
            this.Controls.Add(this.btn_3_1);
            this.Controls.Add(this.btn_3_0);
            this.Controls.Add(this.btn_2_8);
            this.Controls.Add(this.btn_2_7);
            this.Controls.Add(this.btn_2_6);
            this.Controls.Add(this.btn_2_5);
            this.Controls.Add(this.btn_2_4);
            this.Controls.Add(this.btn_2_3);
            this.Controls.Add(this.btn_2_2);
            this.Controls.Add(this.btn_2_1);
            this.Controls.Add(this.btn_2_0);
            this.Controls.Add(this.btn_1_8);
            this.Controls.Add(this.btn_1_7);
            this.Controls.Add(this.btn_1_6);
            this.Controls.Add(this.btn_1_5);
            this.Controls.Add(this.btn_1_4);
            this.Controls.Add(this.btn_1_3);
            this.Controls.Add(this.btn_1_2);
            this.Controls.Add(this.btn_1_1);
            this.Controls.Add(this.btn_1_0);
            this.Controls.Add(this.btn_0_8);
            this.Controls.Add(this.btn_0_7);
            this.Controls.Add(this.btn_0_6);
            this.Controls.Add(this.btn_0_5);
            this.Controls.Add(this.btn_0_4);
            this.Controls.Add(this.btn_0_3);
            this.Controls.Add(this.btn_0_2);
            this.Controls.Add(this.btn_0_1);
            this.Controls.Add(this.btn_0_0);
            this.Controls.Add(this.btnFillBoardRandomly);
            this.Controls.Add(this.btnLoadFromFile);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMineSweeper";
            this.Text = "MineSweeper";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadFromFile;
        private System.Windows.Forms.Button btnFillBoardRandomly;
        private System.Windows.Forms.Button btn_0_0;
        private System.Windows.Forms.Button btn_0_1;
        private System.Windows.Forms.Button btn_0_2;
        private System.Windows.Forms.Button btn_0_3;
        private System.Windows.Forms.Button btn_0_4;
        private System.Windows.Forms.Button btn_0_5;
        private System.Windows.Forms.Button btn_0_6;
        private System.Windows.Forms.Button btn_0_7;
        private System.Windows.Forms.Button btn_0_8;
        private System.Windows.Forms.Button btn_1_0;
        private System.Windows.Forms.Button btn_1_1;
        private System.Windows.Forms.Button btn_1_2;
        private System.Windows.Forms.Button btn_1_3;
        private System.Windows.Forms.Button btn_1_4;
        private System.Windows.Forms.Button btn_1_5;
        private System.Windows.Forms.Button btn_1_6;
        private System.Windows.Forms.Button btn_1_7;
        private System.Windows.Forms.Button btn_1_8;
        private System.Windows.Forms.Button btn_2_0;
        private System.Windows.Forms.Button btn_2_1;
        private System.Windows.Forms.Button btn_2_2;
        private System.Windows.Forms.Button btn_2_3;
        private System.Windows.Forms.Button btn_2_4;
        private System.Windows.Forms.Button btn_2_5;
        private System.Windows.Forms.Button btn_2_6;
        private System.Windows.Forms.Button btn_2_7;
        private System.Windows.Forms.Button btn_2_8;
        private System.Windows.Forms.Button btn_3_0;
        private System.Windows.Forms.Button btn_3_1;
        private System.Windows.Forms.Button btn_3_2;
        private System.Windows.Forms.Button btn_3_3;
        private System.Windows.Forms.Button btn_3_4;
        private System.Windows.Forms.Button btn_3_5;
        private System.Windows.Forms.Button btn_3_6;
        private System.Windows.Forms.Button btn_3_7;
        private System.Windows.Forms.Button btn_3_8;
        private System.Windows.Forms.Button btn_4_0;
        private System.Windows.Forms.Button btn_4_1;
        private System.Windows.Forms.Button btn_4_2;
        private System.Windows.Forms.Button btn_4_3;
        private System.Windows.Forms.Button btn_4_4;
        private System.Windows.Forms.Button btn_4_5;
        private System.Windows.Forms.Button btn_4_6;
        private System.Windows.Forms.Button btn_4_7;
        private System.Windows.Forms.Button btn_4_8;
        private System.Windows.Forms.Button btn_5_0;
        private System.Windows.Forms.Button btn_5_1;
        private System.Windows.Forms.Button btn_5_2;
        private System.Windows.Forms.Button btn_5_3;
        private System.Windows.Forms.Button btn_5_4;
        private System.Windows.Forms.Button btn_5_5;
        private System.Windows.Forms.Button btn_5_6;
        private System.Windows.Forms.Button btn_5_7;
        private System.Windows.Forms.Button btn_5_8;
        private System.Windows.Forms.Button btn_6_0;
        private System.Windows.Forms.Button btn_6_1;
        private System.Windows.Forms.Button btn_6_2;
        private System.Windows.Forms.Button btn_6_3;
        private System.Windows.Forms.Button btn_6_4;
        private System.Windows.Forms.Button btn_6_5;
        private System.Windows.Forms.Button btn_6_6;
        private System.Windows.Forms.Button btn_6_7;
        private System.Windows.Forms.Button btn_6_8;
        private System.Windows.Forms.Button btn_7_0;
        private System.Windows.Forms.Button btn_7_1;
        private System.Windows.Forms.Button btn_7_2;
        private System.Windows.Forms.Button btn_7_3;
        private System.Windows.Forms.Button btn_7_4;
        private System.Windows.Forms.Button btn_7_5;
        private System.Windows.Forms.Button btn_7_6;
        private System.Windows.Forms.Button btn_7_7;
        private System.Windows.Forms.Button btn_7_8;
        private System.Windows.Forms.Button btn_8_0;
        private System.Windows.Forms.Button btn_8_1;
        private System.Windows.Forms.Button btn_8_2;
        private System.Windows.Forms.Button btn_8_3;
        private System.Windows.Forms.Button btn_8_4;
        private System.Windows.Forms.Button btn_8_5;
        private System.Windows.Forms.Button btn_8_6;
        private System.Windows.Forms.Button btn_8_7;
        private System.Windows.Forms.Button btn_8_8;
    }
}

